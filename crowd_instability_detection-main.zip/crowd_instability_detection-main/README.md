# crowd_instability_detection
An AI-powered system that analyzes surveillance videos to detect abnormal crowd movements in real time and generates early alerts to improve public safety.
